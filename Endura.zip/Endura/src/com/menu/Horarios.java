/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.menu;

import com.login.Login;
import java.awt.Color;

/**
 *
 * @author USUARIO
 */
public class Horarios extends javax.swing.JFrame {

    int xMouse, yMouse;
    int pagina=1;
     int puntuacionAnimales;
    int puntuacionDelfin;
    
    /**
     * Creates new form MainMenu
     */
    public Horarios() {
        initComponents();
        System.out.println(testcrono.puntuacion);
        System.out.println(testcrono.contverd);
        puntuacionDelfin = testcrono.contverd;
        puntuacionAnimales = testcrono.puntuacion;
        System.out.println(puntuacionAnimales);
        horariooso1img.setVisible(false);
        horariooso2img.setVisible(false);
        horariooso3img.setVisible(false);
        horariooso4img.setVisible(false);
        horariooso5img.setVisible(false);
        horariooso6img.setVisible(false);
        horariooso7img.setVisible(false);
        horariooso8img.setVisible(false);
        horarioloboimg1.setVisible(false);
        horarioloboimg2.setVisible(false);
        horarioloboimg3.setVisible(false);
        horarioloboimg4.setVisible(false);
        horarioloboimg5.setVisible(false);
        horarioloboimg6.setVisible(false);
        horarioloboimg7.setVisible(false);
        horarioloboimg8.setVisible(false);
        horarioleonimg1.setVisible(false);
        horarioleonimg2.setVisible(false);
        horarioleonimg3.setVisible(false);
        horarioleonimg4.setVisible(false);
        horarioleonimg5.setVisible(false);
        horarioleonimg6.setVisible(false);
        horarioleonimg7.setVisible(false);
        horarioleonimg8.setVisible(false);
        horariodelfinimg1.setVisible(false);
        horariodelfinimg2.setVisible(false);
        horariodelfinimg3.setVisible(false);
        horariodelfinimg4.setVisible(false);
        horariodelfinimg5.setVisible(false);
        horariodelfinimg6.setVisible(false);
        horariodelfinimg7.setVisible(false);
        
        if (puntuacionAnimales>=2&&puntuacionAnimales<=32){
   horarioloboimg1.setVisible(true);
  
    }else if (puntuacionAnimales>32&&puntuacionAnimales<=47){
   horariooso1img.setVisible(true);
    }else if (puntuacionAnimales>47){
        horarioloboimg1.setVisible(true);
    
    } else if (puntuacionDelfin>=7){
 horariodelfinimg1.setVisible(true);
    
    }
    }
    
    
    
   
public void cambiarpagina(){
if (puntuacionAnimales>=2&&puntuacionAnimales<=32){
    horarioleonimg1.setVisible(true);
    if(pagina==1){
        ocultarTodasLasImagenes();
    horarioleonimg2.setVisible(true);
    }else if(pagina==2){
        ocultarTodasLasImagenes();
    horarioleonimg3.setVisible(true);
    }else if(pagina==3){
        ocultarTodasLasImagenes();
    horarioleonimg4.setVisible(true);
    }else if(pagina==4){
        ocultarTodasLasImagenes();
    horarioleonimg5.setVisible(true);
    }else if(pagina==5){
        ocultarTodasLasImagenes();
    horarioleonimg6.setVisible(true);
    }else if(pagina==6){
        ocultarTodasLasImagenes();
    horarioleonimg7.setVisible(true);
    }else if(pagina==7){
        ocultarTodasLasImagenes();
    horarioleonimg8.setVisible(true);
    }
    }else if (puntuacionAnimales>32&&puntuacionAnimales<=47){
        horariooso1img.setVisible(true);
    if(pagina==1){
        ocultarTodasLasImagenes();
    horariooso2img.setVisible(true);
    }else if(pagina==2){
        ocultarTodasLasImagenes();
    horariooso3img.setVisible(true);
    }else if(pagina==3){
        ocultarTodasLasImagenes();
    horariooso4img.setVisible(true);
    }else if(pagina==4){
        ocultarTodasLasImagenes();
    horariooso5img.setVisible(true);
    }else if(pagina==5){
        ocultarTodasLasImagenes();
    horariooso6img.setVisible(true);
    }else if(pagina==6){
        ocultarTodasLasImagenes();
    horariooso7img.setVisible(true);
    }else if(pagina==7){
        ocultarTodasLasImagenes();
    horariooso8img.setVisible(true);
    }
        
    }else if (puntuacionAnimales>47){
        horarioloboimg1.setVisible(true);
        if(pagina==1){
            ocultarTodasLasImagenes();
    horarioloboimg2.setVisible(true);
    }else if(pagina==2){
        ocultarTodasLasImagenes();
    horarioloboimg3.setVisible(true);
    }else if(pagina==3){
        ocultarTodasLasImagenes();
    horarioloboimg4.setVisible(true);
    }else if(pagina==4){
        ocultarTodasLasImagenes();
    horarioloboimg5.setVisible(true);
    }else if(pagina==5){
        ocultarTodasLasImagenes();
    horarioloboimg6.setVisible(true);
    }else if(pagina==6){
        ocultarTodasLasImagenes();
    horarioloboimg7.setVisible(true);
    }else if(pagina==7){
        ocultarTodasLasImagenes();
    horarioloboimg8.setVisible(true);
    }
    
    } else if (puntuacionDelfin>=7){
    horariodelfinimg1.setVisible(true);
    if(pagina==1){
        ocultarTodasLasImagenes();
    horariodelfinimg2.setVisible(true);
    }else if(pagina==2){
        ocultarTodasLasImagenes();
    horariodelfinimg3.setVisible(true);
    }else if(pagina==3){
        ocultarTodasLasImagenes();
    horariodelfinimg4.setVisible(true);
    }else if(pagina==4){
        ocultarTodasLasImagenes();
    horariodelfinimg5.setVisible(true);
    }else if(pagina==5){
        ocultarTodasLasImagenes();
    horariodelfinimg6.setVisible(true);
    }else if(pagina==6){
        ocultarTodasLasImagenes();
    horariodelfinimg7.setVisible(true);
    }
    
    }
}

private void ocultarTodasLasImagenes() {
    
    horarioleonimg1.setVisible(false);
    horarioleonimg2.setVisible(false);
    horarioleonimg3.setVisible(false);
    horarioleonimg4.setVisible(false);
    horarioleonimg5.setVisible(false);
    horarioleonimg6.setVisible(false);
    horarioleonimg7.setVisible(false);
    horarioleonimg8.setVisible(false);

    
    horariooso1img.setVisible(false);
    horariooso2img.setVisible(false);
    horariooso3img.setVisible(false);
    horariooso4img.setVisible(false);
    horariooso5img.setVisible(false);
    horariooso6img.setVisible(false);
    horariooso7img.setVisible(false);
    horariooso8img.setVisible(false);

   
    horarioloboimg1.setVisible(false);
    horarioloboimg2.setVisible(false);
    horarioloboimg3.setVisible(false);
    horarioloboimg4.setVisible(false);
    horarioloboimg5.setVisible(false);
    horarioloboimg6.setVisible(false);
    horarioloboimg7.setVisible(false);
    horarioloboimg8.setVisible(false);

    
    horariodelfinimg1.setVisible(false);
    horariodelfinimg2.setVisible(false);
    horariodelfinimg3.setVisible(false);
    horariodelfinimg4.setVisible(false);
    horariodelfinimg5.setVisible(false);
    horariodelfinimg6.setVisible(false);
    horariodelfinimg7.setVisible(false);
}
    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        menubg = new javax.swing.JPanel();
        enduratxt = new javax.swing.JLabel();
        jSeparator1 = new javax.swing.JSeparator();
        menubtn = new javax.swing.JPanel();
        menutxt = new javax.swing.JLabel();
        cronobtn = new javax.swing.JPanel();
        cronotxt = new javax.swing.JLabel();
        horariobtn = new javax.swing.JPanel();
        horariotxt = new javax.swing.JLabel();
        guiasbtn = new javax.swing.JPanel();
        guiastxt = new javax.swing.JLabel();
        bienestarbtn = new javax.swing.JPanel();
        bienestartxt = new javax.swing.JLabel();
        cuentabtn = new javax.swing.JPanel();
        cuentatxt = new javax.swing.JLabel();
        cerrarbtn = new javax.swing.JPanel();
        cerratxt = new javax.swing.JLabel();
        enduramenubg = new javax.swing.JLabel();
        header = new javax.swing.JPanel();
        exitbtn = new javax.swing.JPanel();
        exittxt = new javax.swing.JLabel();
        horarioloboimg8 = new javax.swing.JLabel();
        horarioloboimg7 = new javax.swing.JLabel();
        horarioloboimg6 = new javax.swing.JLabel();
        horarioloboimg5 = new javax.swing.JLabel();
        horarioloboimg4 = new javax.swing.JLabel();
        horarioloboimg3 = new javax.swing.JLabel();
        horarioloboimg2 = new javax.swing.JLabel();
        horarioloboimg1 = new javax.swing.JLabel();
        horarioleonimg8 = new javax.swing.JLabel();
        horarioleonimg7 = new javax.swing.JLabel();
        horarioleonimg6 = new javax.swing.JLabel();
        horarioleonimg5 = new javax.swing.JLabel();
        horarioleonimg4 = new javax.swing.JLabel();
        horarioleonimg3 = new javax.swing.JLabel();
        horarioleonimg2 = new javax.swing.JLabel();
        horarioleonimg1 = new javax.swing.JLabel();
        horariodelfinimg7 = new javax.swing.JLabel();
        horariodelfinimg6 = new javax.swing.JLabel();
        horariodelfinimg5 = new javax.swing.JLabel();
        horariodelfinimg4 = new javax.swing.JLabel();
        horariodelfinimg3 = new javax.swing.JLabel();
        horariodelfinimg2 = new javax.swing.JLabel();
        horariodelfinimg1 = new javax.swing.JLabel();
        horariooso8img = new javax.swing.JLabel();
        horariooso7img = new javax.swing.JLabel();
        horariooso6img = new javax.swing.JLabel();
        horariooso5img = new javax.swing.JLabel();
        horariooso4img = new javax.swing.JLabel();
        horariooso3img = new javax.swing.JLabel();
        horariooso2img = new javax.swing.JLabel();
        horariooso1img = new javax.swing.JLabel();
        Sigbtn = new javax.swing.JPanel();
        Sigtxt = new javax.swing.JLabel();
        testnotomadotxt = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setLocationByPlatform(true);
        setUndecorated(true);
        setResizable(false);

        menubg.setBackground(new java.awt.Color(255, 255, 255));
        menubg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        enduratxt.setFont(new java.awt.Font("Aharoni", 1, 24)); // NOI18N
        enduratxt.setForeground(new java.awt.Color(255, 255, 255));
        enduratxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        enduratxt.setText("Horarios");
        menubg.add(enduratxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 50, 170, 30));
        menubg.add(jSeparator1, new org.netbeans.lib.awtextra.AbsoluteConstraints(30, 80, 170, 10));

        menubtn.setBackground(new java.awt.Color(55, 67, 136));

        menutxt.setFont(new java.awt.Font("Aharoni", 1, 18)); // NOI18N
        menutxt.setForeground(new java.awt.Color(255, 255, 255));
        menutxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        menutxt.setText("Menú");
        menutxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        menutxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                menutxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                menutxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                menutxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout menubtnLayout = new javax.swing.GroupLayout(menubtn);
        menubtn.setLayout(menubtnLayout);
        menubtnLayout.setHorizontalGroup(
            menubtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menutxt, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
        );
        menubtnLayout.setVerticalGroup(
            menubtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menutxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        menubg.add(menubtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 150, 240, 50));

        cronobtn.setBackground(new java.awt.Color(55, 67, 136));

        cronotxt.setFont(new java.awt.Font("Aharoni", 1, 18)); // NOI18N
        cronotxt.setForeground(new java.awt.Color(255, 255, 255));
        cronotxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cronotxt.setText("Cronotipo");
        cronotxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cronotxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cronotxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cronotxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cronotxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout cronobtnLayout = new javax.swing.GroupLayout(cronobtn);
        cronobtn.setLayout(cronobtnLayout);
        cronobtnLayout.setHorizontalGroup(
            cronobtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cronotxt, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
        );
        cronobtnLayout.setVerticalGroup(
            cronobtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cronotxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        menubg.add(cronobtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 190, 240, 50));

        horariobtn.setBackground(new java.awt.Color(55, 67, 136));

        horariotxt.setFont(new java.awt.Font("Aharoni", 1, 18)); // NOI18N
        horariotxt.setForeground(new java.awt.Color(255, 255, 255));
        horariotxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        horariotxt.setText("Horarios");
        horariotxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        horariotxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                horariotxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                horariotxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout horariobtnLayout = new javax.swing.GroupLayout(horariobtn);
        horariobtn.setLayout(horariobtnLayout);
        horariobtnLayout.setHorizontalGroup(
            horariobtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(horariotxt, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
        );
        horariobtnLayout.setVerticalGroup(
            horariobtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(horariotxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        menubg.add(horariobtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 230, -1, -1));

        guiasbtn.setBackground(new java.awt.Color(55, 67, 136));

        guiastxt.setFont(new java.awt.Font("Aharoni", 1, 18)); // NOI18N
        guiastxt.setForeground(new java.awt.Color(255, 255, 255));
        guiastxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        guiastxt.setText("Guías");
        guiastxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        guiastxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                guiastxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                guiastxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                guiastxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout guiasbtnLayout = new javax.swing.GroupLayout(guiasbtn);
        guiasbtn.setLayout(guiasbtnLayout);
        guiasbtnLayout.setHorizontalGroup(
            guiasbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(guiastxt, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
        );
        guiasbtnLayout.setVerticalGroup(
            guiasbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(guiastxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        menubg.add(guiasbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 270, -1, -1));

        bienestarbtn.setBackground(new java.awt.Color(55, 67, 136));

        bienestartxt.setFont(new java.awt.Font("Aharoni", 1, 18)); // NOI18N
        bienestartxt.setForeground(new java.awt.Color(255, 255, 255));
        bienestartxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        bienestartxt.setText("Bienestar");
        bienestartxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        bienestartxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                bienestartxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                bienestartxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                bienestartxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout bienestarbtnLayout = new javax.swing.GroupLayout(bienestarbtn);
        bienestarbtn.setLayout(bienestarbtnLayout);
        bienestarbtnLayout.setHorizontalGroup(
            bienestarbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bienestartxt, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
        );
        bienestarbtnLayout.setVerticalGroup(
            bienestarbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(bienestartxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        menubg.add(bienestarbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 310, -1, -1));

        cuentabtn.setBackground(new java.awt.Color(55, 67, 136));

        cuentatxt.setFont(new java.awt.Font("Aharoni", 1, 18)); // NOI18N
        cuentatxt.setForeground(new java.awt.Color(255, 255, 255));
        cuentatxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cuentatxt.setText("Cuenta");
        cuentatxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cuentatxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cuentatxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cuentatxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cuentatxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout cuentabtnLayout = new javax.swing.GroupLayout(cuentabtn);
        cuentabtn.setLayout(cuentabtnLayout);
        cuentabtnLayout.setHorizontalGroup(
            cuentabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cuentatxt, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
        );
        cuentabtnLayout.setVerticalGroup(
            cuentabtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cuentatxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        menubg.add(cuentabtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 350, -1, -1));

        cerrarbtn.setBackground(new java.awt.Color(55, 67, 136));

        cerratxt.setFont(new java.awt.Font("Aharoni", 1, 18)); // NOI18N
        cerratxt.setForeground(new java.awt.Color(255, 255, 255));
        cerratxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        cerratxt.setText("Cerrar Sesión");
        cerratxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        cerratxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cerratxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                cerratxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                cerratxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout cerrarbtnLayout = new javax.swing.GroupLayout(cerrarbtn);
        cerrarbtn.setLayout(cerrarbtnLayout);
        cerrarbtnLayout.setHorizontalGroup(
            cerrarbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cerratxt, javax.swing.GroupLayout.DEFAULT_SIZE, 240, Short.MAX_VALUE)
        );
        cerrarbtnLayout.setVerticalGroup(
            cerrarbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(cerratxt, javax.swing.GroupLayout.DEFAULT_SIZE, 50, Short.MAX_VALUE)
        );

        menubg.add(cerrarbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 390, -1, -1));

        enduramenubg.setIcon(new javax.swing.ImageIcon(getClass().getResource("/com/images/Captura de pantalla 2024-04-28 222308.png"))); // NOI18N
        enduramenubg.setText("jLabel1");
        menubg.add(enduramenubg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 240, 500));

        header.setBackground(new java.awt.Color(255, 255, 255));
        header.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                headerMouseDragged(evt);
            }
        });
        header.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                headerMousePressed(evt);
            }
        });

        exitbtn.setBackground(new java.awt.Color(255, 255, 255));

        exittxt.setFont(new java.awt.Font("Aharoni", 1, 12)); // NOI18N
        exittxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exittxt.setText("X");
        exittxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        exittxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exittxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exittxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exittxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout exitbtnLayout = new javax.swing.GroupLayout(exitbtn);
        exitbtn.setLayout(exitbtnLayout);
        exitbtnLayout.setHorizontalGroup(
            exitbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exittxt, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 54, Short.MAX_VALUE)
        );
        exitbtnLayout.setVerticalGroup(
            exitbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, exitbtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(exittxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout headerLayout = new javax.swing.GroupLayout(header);
        header.setLayout(headerLayout);
        headerLayout.setHorizontalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, headerLayout.createSequentialGroup()
                .addGap(0, 746, Short.MAX_VALUE)
                .addComponent(exitbtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );
        headerLayout.setVerticalGroup(
            headerLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exitbtn, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        menubg.add(header, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 40));

        horarioloboimg8.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariolobo8PNG.png")); // NOI18N
        horarioloboimg8.setText("jLabel2");
        menubg.add(horarioloboimg8, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioloboimg7.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariolobo7PNG.png")); // NOI18N
        horarioloboimg7.setText("jLabel2");
        menubg.add(horarioloboimg7, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioloboimg6.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariolobo6PNG.png")); // NOI18N
        horarioloboimg6.setText("jLabel2");
        menubg.add(horarioloboimg6, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioloboimg5.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariolobo5PNG.png")); // NOI18N
        horarioloboimg5.setText("jLabel2");
        menubg.add(horarioloboimg5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioloboimg4.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariolobo4PNG.png")); // NOI18N
        horarioloboimg4.setText("jLabel2");
        menubg.add(horarioloboimg4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioloboimg3.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariolobo3PNG.png")); // NOI18N
        horarioloboimg3.setText("jLabel2");
        menubg.add(horarioloboimg3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioloboimg2.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariolobo2PNG.png")); // NOI18N
        horarioloboimg2.setText("jLabel2");
        menubg.add(horarioloboimg2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioloboimg1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariolobo1PNG.png")); // NOI18N
        horarioloboimg1.setText("jLabel2");
        menubg.add(horarioloboimg1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioleonimg8.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horarioleon8PNG.png")); // NOI18N
        horarioleonimg8.setText("jLabel2");
        menubg.add(horarioleonimg8, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioleonimg7.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horarioleon7PNG.png")); // NOI18N
        horarioleonimg7.setText("jLabel2");
        menubg.add(horarioleonimg7, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioleonimg6.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horarioleon6PNG.png")); // NOI18N
        horarioleonimg6.setText("jLabel2");
        menubg.add(horarioleonimg6, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioleonimg5.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horarioleon5PNG.png")); // NOI18N
        horarioleonimg5.setText("jLabel2");
        menubg.add(horarioleonimg5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioleonimg4.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horarioleon4PNG.png")); // NOI18N
        horarioleonimg4.setText("jLabel2");
        menubg.add(horarioleonimg4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioleonimg3.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horarioleon3PNG.png")); // NOI18N
        horarioleonimg3.setText("jLabel2");
        menubg.add(horarioleonimg3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horarioleonimg2.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horarioleon2PNG.png")); // NOI18N
        menubg.add(horarioleonimg2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 20, 550, 360));

        horarioleonimg1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horarioleon1PNG.png")); // NOI18N
        horarioleonimg1.setText("jLabel2");
        menubg.add(horarioleonimg1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariodelfinimg7.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariodelfin7PNG.png")); // NOI18N
        horariodelfinimg7.setText("jLabel2");
        menubg.add(horariodelfinimg7, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariodelfinimg6.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariodelfin6PNG.png")); // NOI18N
        horariodelfinimg6.setText("jLabel2");
        menubg.add(horariodelfinimg6, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariodelfinimg5.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariodelfin5PNG.png")); // NOI18N
        horariodelfinimg5.setText("jLabel2");
        menubg.add(horariodelfinimg5, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariodelfinimg4.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariodelfin4PNG.png")); // NOI18N
        horariodelfinimg4.setText("jLabel2");
        menubg.add(horariodelfinimg4, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariodelfinimg3.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariodelfin3PNG.png")); // NOI18N
        horariodelfinimg3.setText("jLabel2");
        menubg.add(horariodelfinimg3, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariodelfinimg2.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariodelfin2PNG.png")); // NOI18N
        horariodelfinimg2.setText("jLabel2");
        menubg.add(horariodelfinimg2, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariodelfinimg1.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariosendura\\horariodelfin1PNG.png")); // NOI18N
        horariodelfinimg1.setText("jLabel2");
        menubg.add(horariodelfinimg1, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariooso8img.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariooso_8.png")); // NOI18N
        horariooso8img.setText("jLabel2");
        menubg.add(horariooso8img, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariooso7img.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariooso_7.png")); // NOI18N
        horariooso7img.setText("jLabel2");
        menubg.add(horariooso7img, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariooso6img.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariooso_6.png")); // NOI18N
        horariooso6img.setText("jLabel2");
        menubg.add(horariooso6img, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariooso5img.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariooso_5.png")); // NOI18N
        horariooso5img.setText("jLabel2");
        menubg.add(horariooso5img, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariooso4img.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariooso_4.png")); // NOI18N
        horariooso4img.setText("jLabel2");
        menubg.add(horariooso4img, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariooso3img.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariooso_3.png")); // NOI18N
        horariooso3img.setText("jLabel2");
        menubg.add(horariooso3img, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariooso2img.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariooso_2.png")); // NOI18N
        horariooso2img.setText("jLabel2");
        menubg.add(horariooso2img, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        horariooso1img.setIcon(new javax.swing.ImageIcon("C:\\Users\\USUARIO\\OneDrive - OCH ASSURANCE & AUDIT S.A\\Imágenes\\horariooso_1.png")); // NOI18N
        horariooso1img.setText("jLabel1");
        menubg.add(horariooso1img, new org.netbeans.lib.awtextra.AbsoluteConstraints(250, 70, 550, 360));

        Sigbtn.setBackground(new java.awt.Color(153, 153, 153));

        Sigtxt.setBackground(new java.awt.Color(153, 153, 153));
        Sigtxt.setFont(new java.awt.Font("Lucida Sans Unicode", 0, 14)); // NOI18N
        Sigtxt.setForeground(new java.awt.Color(255, 255, 255));
        Sigtxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Sigtxt.setText("Siguiente");
        Sigtxt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Sigtxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                SigtxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                SigtxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                SigtxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout SigbtnLayout = new javax.swing.GroupLayout(Sigbtn);
        Sigbtn.setLayout(SigbtnLayout);
        SigbtnLayout.setHorizontalGroup(
            SigbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Sigtxt, javax.swing.GroupLayout.DEFAULT_SIZE, 90, Short.MAX_VALUE)
        );
        SigbtnLayout.setVerticalGroup(
            SigbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Sigtxt, javax.swing.GroupLayout.DEFAULT_SIZE, 30, Short.MAX_VALUE)
        );

        menubg.add(Sigbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(690, 440, 90, 30));

        testnotomadotxt.setFont(new java.awt.Font("Bahnschrift", 1, 18)); // NOI18N
        testnotomadotxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        testnotomadotxt.setText("Toma el test de cronotipos para descubrir tu potencial!");
        menubg.add(testnotomadotxt, new org.netbeans.lib.awtextra.AbsoluteConstraints(280, 200, 490, 20));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menubg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(menubg, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void menutxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menutxtMouseEntered
        menubtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_menutxtMouseEntered

    private void menutxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menutxtMouseExited
        menubtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_menutxtMouseExited

    private void cronotxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cronotxtMouseEntered
        cronobtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_cronotxtMouseEntered

    private void cronotxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cronotxtMouseExited
        cronobtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_cronotxtMouseExited

    private void horariotxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_horariotxtMouseEntered
        horariobtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_horariotxtMouseEntered

    private void horariotxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_horariotxtMouseExited
       horariobtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_horariotxtMouseExited

    private void guiastxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_guiastxtMouseEntered
        guiasbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_guiastxtMouseEntered

    private void guiastxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_guiastxtMouseExited
        guiasbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_guiastxtMouseExited

    private void bienestartxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bienestartxtMouseEntered
        bienestarbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_bienestartxtMouseEntered

    private void bienestartxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bienestartxtMouseExited
      bienestarbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_bienestartxtMouseExited

    private void cuentatxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cuentatxtMouseEntered
        cuentabtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_cuentatxtMouseEntered

    private void cuentatxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cuentatxtMouseExited
       cuentabtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_cuentatxtMouseExited

    private void cerratxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cerratxtMouseEntered
        cerrarbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_cerratxtMouseEntered

    private void cerratxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cerratxtMouseExited
        cerrarbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_cerratxtMouseExited

    private void headerMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_headerMousePressed

    private void headerMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_headerMouseDragged
       int x = evt.getXOnScreen();
       int y = evt.getYOnScreen();
       this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_headerMouseDragged

    private void exittxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exittxtMouseEntered
       exitbtn.setBackground(Color.red);
       exittxt.setForeground(Color.white);
    }//GEN-LAST:event_exittxtMouseEntered

    private void exittxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exittxtMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exittxtMouseClicked

    private void exittxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exittxtMouseExited
        exitbtn.setBackground(Color.white);
        exittxt.setForeground(Color.black);
    }//GEN-LAST:event_exittxtMouseExited

    private void cerratxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cerratxtMouseClicked
       Login login = new Login();
    login.setVisible(true);
    dispose();
    }//GEN-LAST:event_cerratxtMouseClicked

    private void menutxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_menutxtMouseClicked
        MainMenu mainMenu = new MainMenu();
    mainMenu.setVisible(true);
    dispose();
    }//GEN-LAST:event_menutxtMouseClicked

    private void bienestartxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_bienestartxtMouseClicked
         Bienestar bienestar = new Bienestar();
    bienestar.setVisible(true);
    dispose();
    }//GEN-LAST:event_bienestartxtMouseClicked

    private void cuentatxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cuentatxtMouseClicked
        Cuenta cuenta = new Cuenta();
    cuenta.setVisible(true);
    dispose();
    }//GEN-LAST:event_cuentatxtMouseClicked

    private void guiastxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_guiastxtMouseClicked
        Guias guias = new Guias();
    guias.setVisible(true);
    dispose();
    }//GEN-LAST:event_guiastxtMouseClicked

    private void cronotxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cronotxtMouseClicked
        Cronotipo cronotipo = new Cronotipo();
    cronotipo.setVisible(true);
    dispose();
    }//GEN-LAST:event_cronotxtMouseClicked

    private void SigtxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SigtxtMouseClicked
       cambiarpagina();
       pagina++;
    }//GEN-LAST:event_SigtxtMouseClicked

    private void SigtxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SigtxtMouseEntered
        Sigbtn.setBackground(new Color(204,204,204));
    }//GEN-LAST:event_SigtxtMouseEntered

    private void SigtxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_SigtxtMouseExited
        Sigbtn.setBackground(new Color(153,153,153));
    }//GEN-LAST:event_SigtxtMouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Horarios.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new Horarios().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Sigbtn;
    private javax.swing.JLabel Sigtxt;
    private javax.swing.JPanel bienestarbtn;
    private javax.swing.JLabel bienestartxt;
    private javax.swing.JPanel cerrarbtn;
    private javax.swing.JLabel cerratxt;
    private javax.swing.JPanel cronobtn;
    private javax.swing.JLabel cronotxt;
    private javax.swing.JPanel cuentabtn;
    private javax.swing.JLabel cuentatxt;
    private javax.swing.JLabel enduramenubg;
    private javax.swing.JLabel enduratxt;
    private javax.swing.JPanel exitbtn;
    private javax.swing.JLabel exittxt;
    private javax.swing.JPanel guiasbtn;
    private javax.swing.JLabel guiastxt;
    private javax.swing.JPanel header;
    private javax.swing.JPanel horariobtn;
    private javax.swing.JLabel horariodelfinimg1;
    private javax.swing.JLabel horariodelfinimg2;
    private javax.swing.JLabel horariodelfinimg3;
    private javax.swing.JLabel horariodelfinimg4;
    private javax.swing.JLabel horariodelfinimg5;
    private javax.swing.JLabel horariodelfinimg6;
    private javax.swing.JLabel horariodelfinimg7;
    private javax.swing.JLabel horarioleonimg1;
    private javax.swing.JLabel horarioleonimg2;
    private javax.swing.JLabel horarioleonimg3;
    private javax.swing.JLabel horarioleonimg4;
    private javax.swing.JLabel horarioleonimg5;
    private javax.swing.JLabel horarioleonimg6;
    private javax.swing.JLabel horarioleonimg7;
    private javax.swing.JLabel horarioleonimg8;
    private javax.swing.JLabel horarioloboimg1;
    private javax.swing.JLabel horarioloboimg2;
    private javax.swing.JLabel horarioloboimg3;
    private javax.swing.JLabel horarioloboimg4;
    private javax.swing.JLabel horarioloboimg5;
    private javax.swing.JLabel horarioloboimg6;
    private javax.swing.JLabel horarioloboimg7;
    private javax.swing.JLabel horarioloboimg8;
    private javax.swing.JLabel horariooso1img;
    private javax.swing.JLabel horariooso2img;
    private javax.swing.JLabel horariooso3img;
    private javax.swing.JLabel horariooso4img;
    private javax.swing.JLabel horariooso5img;
    private javax.swing.JLabel horariooso6img;
    private javax.swing.JLabel horariooso7img;
    private javax.swing.JLabel horariooso8img;
    private javax.swing.JLabel horariotxt;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JPanel menubg;
    private javax.swing.JPanel menubtn;
    private javax.swing.JLabel menutxt;
    private javax.swing.JLabel testnotomadotxt;
    // End of variables declaration//GEN-END:variables
}
