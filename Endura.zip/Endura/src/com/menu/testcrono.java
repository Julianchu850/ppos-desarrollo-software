/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package com.menu;

import java.awt.Color;

/**
 *
 * @author USUARIO
 */
public class testcrono extends javax.swing.JFrame {

   

    int xMouse, yMouse;
    int pregunta = 1;
    static int puntuacion = 0;
   static int contverd= 1;
   
    


/**
     * Creates new form testcrono
     */
    public testcrono() {
        initComponents();
       
        opcion1.setVisible(false);
        opcion1txt.setVisible(false);
        opcion2.setVisible(false);
        opcion2txt.setVisible(false);
        opcion3.setVisible(false);
        opcion3txt.setVisible(false);
        preguntabg2.setVisible(false);
        preguntabg3.setVisible(false);
        preguntabg4.setVisible(false);
        preguntabg5.setVisible(false);
        preguntabg6.setVisible(false);
        preguntabg7.setVisible(false);
        preguntabg8.setVisible(false);
        preguntabg9.setVisible(false);
        preguntabg10.setVisible(false);
        preguntabg11.setVisible(false);
        preguntabg12.setVisible(false);
        preguntabg13.setVisible(false);
        preguntabg14.setVisible(false);
        preguntabg15.setVisible(false);
        preguntabg16.setVisible(false);
        preguntabg17.setVisible(false);
        preguntabg18.setVisible(false);
        preguntabg19.setVisible(false);
        preguntabg20.setVisible(false);
        preguntabg21.setVisible(false);
        preguntabg22.setVisible(false);
        preguntabg23.setVisible(false);
        preguntabg24.setVisible(false);
        preguntabg25.setVisible(false);
        preguntabg26.setVisible(false);
        preguntabg27.setVisible(false);
        preguntabg28.setVisible(false);
        preguntabg29.setVisible(false);
        preguntabg30.setVisible(false);
        preguntabg31.setVisible(false);

        preguntatxt2.setVisible(false);
        preguntatxt3.setVisible(false);
        preguntatxt4.setVisible(false);
        preguntatxt5.setVisible(false);
        preguntatxt6.setVisible(false);
        preguntatxt7.setVisible(false);
        preguntatxt8.setVisible(false);
        preguntatxt9.setVisible(false);
        preguntatxt10.setVisible(false);
        preguntatxt11.setVisible(false);
        preguntatxt12.setVisible(false);
        preguntatxt13.setVisible(false);
        preguntatxt14.setVisible(false);
        preguntatxt15.setVisible(false);
        preguntatxt16.setVisible(false);
        preguntatxt17.setVisible(false);
        preguntatxt18.setVisible(false);
        preguntatxt19.setVisible(false);
        preguntatxt20.setVisible(false);
        preguntatxt21.setVisible(false);
        preguntatxt22.setVisible(false);
        preguntatxt23.setVisible(false);
        preguntatxt24.setVisible(false);
        preguntatxt25.setVisible(false);
        preguntatxt26.setVisible(false);
        preguntatxt27.setVisible(false);
        preguntatxt28.setVisible(false);
        preguntatxt29.setVisible(false);
        preguntatxt30.setVisible(false);
        preguntatxt31.setVisible(false);
        
    pregunta = 1;
    puntuacion = 0;
   contverd= 1;

    }
    
    
    
    private void cambiarPregunta(){
        
    if( pregunta == 1){
         preguntabg2.setVisible(true);
         preguntatxt2.setVisible(true);
    } else if(pregunta == 2){
        preguntabg3.setVisible(true);
        preguntatxt3.setVisible(true);

    } else if (pregunta == 3){
        preguntabg4.setVisible(true);
        preguntatxt4.setVisible(true);
    }  else if(pregunta == 4){
        preguntabg5.setVisible(true);
        preguntatxt5.setVisible(true);
    } else if(pregunta == 5){
        preguntabg6.setVisible(true);
        preguntatxt6.setVisible(true);
    } else if(pregunta == 6){
        preguntabg7.setVisible(true);
        preguntatxt7.setVisible(true);
    } else if(pregunta == 7){
        preguntabg8.setVisible(true);
        preguntatxt8.setVisible(true);
    } else if(pregunta == 8){
        preguntabg9.setVisible(true);
        preguntatxt9.setVisible(true);
    } else if(pregunta == 9){
        preguntabg10.setVisible(true);
        preguntatxt10.setVisible(true);
    } else if(pregunta == 10){
        preguntabg11.setVisible(true);
        preguntatxt11.setVisible(true);
    } else if(pregunta == 11){
        Vtxt.setVisible(false);
        vbtn.setVisible(false);
        Fbtn.setVisible(false);
        Ftxt.setVisible(false);
        opcion1.setVisible(true);
        opcion1txt.setVisible(true);
        opcion2.setVisible(true);
        opcion2txt.setVisible(true);
        opcion3.setVisible(true);
        opcion3txt.setVisible(true);
        preguntabg12.setVisible(true);
        preguntatxt12.setVisible(true);
    } else if(pregunta == 12){
    preguntabg13.setVisible(true);
    preguntatxt13.setVisible(true);
    } else if(pregunta == 13){
    preguntabg14.setVisible(true);
    preguntatxt14.setVisible(true);
    } else if(pregunta == 14){
    preguntabg15.setVisible(true);
    preguntatxt15.setVisible(true);
    } else if(pregunta == 15){
    preguntabg16.setVisible(true);
    preguntatxt16.setVisible(true);
    } else if(pregunta == 16){
    preguntabg17.setVisible(true);
    preguntatxt17.setVisible(true);
    } else if(pregunta == 17){
    preguntabg18.setVisible(true);
    preguntatxt18.setVisible(true);
    } else if(pregunta == 18){
    preguntabg19.setVisible(true);
    preguntatxt19.setVisible(true);
    } else if(pregunta == 19){
    preguntabg20.setVisible(true);
    preguntatxt20.setVisible(true);
    } else if(pregunta == 20){
    preguntabg21.setVisible(true);
    preguntatxt21.setVisible(true);
    } else if(pregunta == 21){
    preguntabg22.setVisible(true);
    preguntatxt22.setVisible(true);
    } else if(pregunta == 22){
    preguntabg23.setVisible(true);
    preguntatxt23.setVisible(true);
    } else if(pregunta == 23){
    preguntabg24.setVisible(true);
    preguntatxt24.setVisible(true);
    } else if(pregunta == 24){
    preguntabg25.setVisible(true);
    preguntatxt25.setVisible(true);
    } else if(pregunta == 25){
    preguntabg26.setVisible(true);
    preguntatxt26.setVisible(true);
    } else if(pregunta == 26){
    preguntabg27.setVisible(true);
    preguntatxt27.setVisible(true);
    } else if(pregunta == 27){
    preguntabg28.setVisible(true);
    preguntatxt28.setVisible(true);
    } else if(pregunta == 28){
    preguntabg29.setVisible(true);
    preguntatxt29.setVisible(true);
    } else if(pregunta == 29){
    preguntabg30.setVisible(true);
    preguntatxt30.setVisible(true);
    } else if(pregunta == 30){
    preguntabg31.setVisible(true);
    preguntatxt31.setVisible(true);
}

    
    pregunta++;
    
    preguntatxt.setText("PREGUNTA "+ pregunta);
    }
    
    
  
   

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        testbg = new javax.swing.JPanel();
        HEADER = new javax.swing.JPanel();
        extbtn = new javax.swing.JPanel();
        exittxt = new javax.swing.JLabel();
        preguntabg = new javax.swing.JPanel();
        preguntatxt = new javax.swing.JLabel();
        opcion1 = new javax.swing.JPanel();
        opcion1txt = new javax.swing.JLabel();
        opcion2 = new javax.swing.JPanel();
        opcion2txt = new javax.swing.JLabel();
        opcion3 = new javax.swing.JPanel();
        opcion3txt = new javax.swing.JLabel();
        vbtn = new javax.swing.JPanel();
        Vtxt = new javax.swing.JLabel();
        Fbtn = new javax.swing.JPanel();
        Ftxt = new javax.swing.JLabel();
        preguntabg31 = new javax.swing.JPanel();
        preguntatxt31 = new javax.swing.JLabel();
        preguntabg30 = new javax.swing.JPanel();
        preguntatxt30 = new javax.swing.JLabel();
        preguntabg29 = new javax.swing.JPanel();
        preguntatxt29 = new javax.swing.JLabel();
        preguntabg28 = new javax.swing.JPanel();
        preguntatxt28 = new javax.swing.JLabel();
        preguntabg27 = new javax.swing.JPanel();
        preguntatxt27 = new javax.swing.JLabel();
        preguntabg26 = new javax.swing.JPanel();
        preguntatxt26 = new javax.swing.JLabel();
        preguntabg25 = new javax.swing.JPanel();
        preguntatxt25 = new javax.swing.JLabel();
        preguntabg24 = new javax.swing.JPanel();
        preguntatxt24 = new javax.swing.JLabel();
        preguntabg23 = new javax.swing.JPanel();
        preguntatxt23 = new javax.swing.JLabel();
        preguntabg22 = new javax.swing.JPanel();
        preguntatxt22 = new javax.swing.JLabel();
        preguntabg21 = new javax.swing.JPanel();
        preguntatxt21 = new javax.swing.JLabel();
        preguntabg20 = new javax.swing.JPanel();
        preguntatxt20 = new javax.swing.JLabel();
        preguntabg19 = new javax.swing.JPanel();
        preguntatxt19 = new javax.swing.JLabel();
        preguntabg18 = new javax.swing.JPanel();
        preguntatxt18 = new javax.swing.JLabel();
        preguntabg17 = new javax.swing.JPanel();
        preguntatxt17 = new javax.swing.JLabel();
        preguntabg16 = new javax.swing.JPanel();
        preguntatxt16 = new javax.swing.JLabel();
        preguntabg15 = new javax.swing.JPanel();
        preguntatxt15 = new javax.swing.JLabel();
        preguntabg14 = new javax.swing.JPanel();
        preguntatxt14 = new javax.swing.JLabel();
        preguntabg13 = new javax.swing.JPanel();
        preguntatxt13 = new javax.swing.JLabel();
        preguntabg12 = new javax.swing.JPanel();
        preguntatxt12 = new javax.swing.JLabel();
        preguntabg11 = new javax.swing.JPanel();
        preguntatxt11 = new javax.swing.JLabel();
        preguntabg10 = new javax.swing.JPanel();
        preguntatxt10 = new javax.swing.JLabel();
        preguntabg9 = new javax.swing.JPanel();
        preguntatxt9 = new javax.swing.JLabel();
        preguntabg8 = new javax.swing.JPanel();
        preguntatxt8 = new javax.swing.JLabel();
        preguntabg7 = new javax.swing.JPanel();
        preguntatxt7 = new javax.swing.JLabel();
        preguntabg6 = new javax.swing.JPanel();
        preguntatxt6 = new javax.swing.JLabel();
        preguntabg5 = new javax.swing.JPanel();
        preguntatxt5 = new javax.swing.JLabel();
        preguntabg4 = new javax.swing.JPanel();
        preguntatxt4 = new javax.swing.JLabel();
        preguntabg3 = new javax.swing.JPanel();
        preguntatxt3 = new javax.swing.JLabel();
        preguntabg2 = new javax.swing.JPanel();
        preguntatxt2 = new javax.swing.JLabel();
        preguntabg1 = new javax.swing.JPanel();
        preguntatxt1 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setUndecorated(true);

        testbg.setBackground(new java.awt.Color(255, 255, 255));
        testbg.setLayout(new org.netbeans.lib.awtextra.AbsoluteLayout());

        HEADER.setBackground(new java.awt.Color(55, 67, 136));
        HEADER.addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                HEADERMouseDragged(evt);
            }
        });
        HEADER.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                HEADERMousePressed(evt);
            }
        });

        extbtn.setBackground(new java.awt.Color(55, 67, 136));

        exittxt.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        exittxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        exittxt.setText("X");
        exittxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                exittxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                exittxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                exittxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout extbtnLayout = new javax.swing.GroupLayout(extbtn);
        extbtn.setLayout(extbtnLayout);
        extbtnLayout.setHorizontalGroup(
            extbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(exittxt, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
        );
        extbtnLayout.setVerticalGroup(
            extbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, extbtnLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(exittxt, javax.swing.GroupLayout.PREFERRED_SIZE, 40, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        javax.swing.GroupLayout HEADERLayout = new javax.swing.GroupLayout(HEADER);
        HEADER.setLayout(HEADERLayout);
        HEADERLayout.setHorizontalGroup(
            HEADERLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HEADERLayout.createSequentialGroup()
                .addComponent(extbtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 754, Short.MAX_VALUE))
        );
        HEADERLayout.setVerticalGroup(
            HEADERLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(HEADERLayout.createSequentialGroup()
                .addGap(0, 0, Short.MAX_VALUE)
                .addComponent(extbtn, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        testbg.add(HEADER, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 40));

        preguntabg.setBackground(new java.awt.Color(55, 67, 136));

        preguntatxt.setFont(new java.awt.Font("Franklin Gothic Demi", 2, 48)); // NOI18N
        preguntatxt.setForeground(new java.awt.Color(255, 255, 255));
        preguntatxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        preguntatxt.setText("PREGUNTA 1");

        javax.swing.GroupLayout preguntabgLayout = new javax.swing.GroupLayout(preguntabg);
        preguntabg.setLayout(preguntabgLayout);
        preguntabgLayout.setHorizontalGroup(
            preguntabgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabgLayout.createSequentialGroup()
                .addContainerGap(180, Short.MAX_VALUE)
                .addComponent(preguntatxt, javax.swing.GroupLayout.PREFERRED_SIZE, 460, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(160, 160, 160))
        );
        preguntabgLayout.setVerticalGroup(
            preguntabgLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabgLayout.createSequentialGroup()
                .addGap(0, 20, Short.MAX_VALUE)
                .addComponent(preguntatxt, javax.swing.GroupLayout.PREFERRED_SIZE, 70, javax.swing.GroupLayout.PREFERRED_SIZE))
        );

        testbg.add(preguntabg, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 0, 800, 90));

        opcion1.setBackground(new java.awt.Color(55, 67, 136));
        opcion1.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                opcion1MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                opcion1MouseExited(evt);
            }
        });

        opcion1txt.setBackground(new java.awt.Color(55, 67, 136));
        opcion1txt.setFont(new java.awt.Font("Franklin Gothic Book", 2, 18)); // NOI18N
        opcion1txt.setForeground(new java.awt.Color(255, 255, 255));
        opcion1txt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        opcion1txt.setText("1");
        opcion1txt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        opcion1txt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcion1txtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                opcion1txtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                opcion1txtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout opcion1Layout = new javax.swing.GroupLayout(opcion1);
        opcion1.setLayout(opcion1Layout);
        opcion1Layout.setHorizontalGroup(
            opcion1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(opcion1txt, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
        );
        opcion1Layout.setVerticalGroup(
            opcion1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(opcion1txt, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );

        testbg.add(opcion1, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 390, 130, 70));

        opcion2.setBackground(new java.awt.Color(55, 67, 136));
        opcion2.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                opcion2MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                opcion2MouseExited(evt);
            }
        });

        opcion2txt.setBackground(new java.awt.Color(55, 67, 136));
        opcion2txt.setFont(new java.awt.Font("Franklin Gothic Book", 2, 18)); // NOI18N
        opcion2txt.setForeground(new java.awt.Color(255, 255, 255));
        opcion2txt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        opcion2txt.setText("2");
        opcion2txt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        opcion2txt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcion2txtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                opcion2txtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                opcion2txtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout opcion2Layout = new javax.swing.GroupLayout(opcion2);
        opcion2.setLayout(opcion2Layout);
        opcion2Layout.setHorizontalGroup(
            opcion2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(opcion2txt, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
        );
        opcion2Layout.setVerticalGroup(
            opcion2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(opcion2txt, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );

        testbg.add(opcion2, new org.netbeans.lib.awtextra.AbsoluteConstraints(330, 390, 130, 70));

        opcion3.setBackground(new java.awt.Color(55, 67, 136));
        opcion3.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                opcion3MouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                opcion3MouseExited(evt);
            }
        });

        opcion3txt.setBackground(new java.awt.Color(55, 67, 136));
        opcion3txt.setFont(new java.awt.Font("Franklin Gothic Book", 2, 18)); // NOI18N
        opcion3txt.setForeground(new java.awt.Color(255, 255, 255));
        opcion3txt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        opcion3txt.setText("3");
        opcion3txt.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        opcion3txt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                opcion3txtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                opcion3txtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                opcion3txtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout opcion3Layout = new javax.swing.GroupLayout(opcion3);
        opcion3.setLayout(opcion3Layout);
        opcion3Layout.setHorizontalGroup(
            opcion3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(opcion3txt, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
        );
        opcion3Layout.setVerticalGroup(
            opcion3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(opcion3txt, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );

        testbg.add(opcion3, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 390, -1, -1));

        vbtn.setBackground(new java.awt.Color(55, 67, 136));
        vbtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        vbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                vbtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                vbtnMouseExited(evt);
            }
        });

        Vtxt.setBackground(new java.awt.Color(55, 67, 136));
        Vtxt.setFont(new java.awt.Font("Franklin Gothic Book", 2, 18)); // NOI18N
        Vtxt.setForeground(new java.awt.Color(255, 255, 255));
        Vtxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Vtxt.setText("Verdadero");
        Vtxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                VtxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                VtxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                VtxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout vbtnLayout = new javax.swing.GroupLayout(vbtn);
        vbtn.setLayout(vbtnLayout);
        vbtnLayout.setHorizontalGroup(
            vbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Vtxt, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
        );
        vbtnLayout.setVerticalGroup(
            vbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Vtxt, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );

        testbg.add(vbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(90, 390, 130, 70));

        Fbtn.setBackground(new java.awt.Color(55, 67, 136));
        Fbtn.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        Fbtn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                FbtnMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                FbtnMouseExited(evt);
            }
        });

        Ftxt.setBackground(new java.awt.Color(55, 67, 136));
        Ftxt.setFont(new java.awt.Font("Franklin Gothic Book", 2, 18)); // NOI18N
        Ftxt.setForeground(new java.awt.Color(255, 255, 255));
        Ftxt.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        Ftxt.setText("Falso");
        Ftxt.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                FtxtMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                FtxtMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                FtxtMouseExited(evt);
            }
        });

        javax.swing.GroupLayout FbtnLayout = new javax.swing.GroupLayout(Fbtn);
        Fbtn.setLayout(FbtnLayout);
        FbtnLayout.setHorizontalGroup(
            FbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Ftxt, javax.swing.GroupLayout.DEFAULT_SIZE, 130, Short.MAX_VALUE)
        );
        FbtnLayout.setVerticalGroup(
            FbtnLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(Ftxt, javax.swing.GroupLayout.DEFAULT_SIZE, 70, Short.MAX_VALUE)
        );

        testbg.add(Fbtn, new org.netbeans.lib.awtextra.AbsoluteConstraints(590, 390, -1, -1));

        preguntabg31.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt31.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt31.setText("<html>\n¿Cómo describes tu satisfacción general con la vida?<html>\n\n<html>\n--------------------------------------------------------\n1- Alta\n--------------------------------------------------------\n2- Buena\n--------------------------------------------------------\n3- Baja\n<html>");

        javax.swing.GroupLayout preguntabg31Layout = new javax.swing.GroupLayout(preguntabg31);
        preguntabg31.setLayout(preguntabg31Layout);
        preguntabg31Layout.setHorizontalGroup(
            preguntabg31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg31Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt31, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg31Layout.setVerticalGroup(
            preguntabg31Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg31Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(preguntatxt31, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg31, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg30.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt30.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt30.setText("<html>\n¿Qué tan seguido percibes síntomas de insomnio?<html>\n\n<html>\n--------------------------------------------------------\n1- Poco frecuente, solo cuando me estoy ajustando a nueva zona horaria\n--------------------------------------------------------\n2- Ocasionalmente, cuando estoy pasando por un mal momento, o me siento estresado(a)\n--------------------------------------------------------\n3- Crónico. Muy seguido\n<html>");

        javax.swing.GroupLayout preguntabg30Layout = new javax.swing.GroupLayout(preguntabg30);
        preguntabg30.setLayout(preguntabg30Layout);
        preguntabg30Layout.setHorizontalGroup(
            preguntabg30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg30Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt30, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg30Layout.setVerticalGroup(
            preguntabg30Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg30Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(preguntatxt30, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg30, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg29.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt29.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt29.setText("<html>\n¿Cómo describes tu apetito, después de media hora de haber despertado?<html>\n\n<html>\n--------------------------------------------------------\n1- Con mucha hambre\n--------------------------------------------------------\n2- Con algo de hambre\n--------------------------------------------------------\n3- No siento hambre\n<html>");

        javax.swing.GroupLayout preguntabg29Layout = new javax.swing.GroupLayout(preguntabg29);
        preguntabg29.setLayout(preguntabg29Layout);
        preguntabg29Layout.setHorizontalGroup(
            preguntabg29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg29Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt29, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg29Layout.setVerticalGroup(
            preguntabg29Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg29Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(preguntatxt29, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg29, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg28.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt28.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt28.setText("<html>\nEn cuanto despiertas en la mañana (después de unos minutos), normalmente ¿cómo te describes?<html>\n\n<html>\n--------------------------------------------------------\n1- Activo, con ojos brillantes, listos para toda la acción\n--------------------------------------------------------\n2- Aturdido(a) pero no confundido(a)\n--------------------------------------------------------\n3- Dormido(a), los párpados como pegados con cemento\n<html>");

        javax.swing.GroupLayout preguntabg28Layout = new javax.swing.GroupLayout(preguntabg28);
        preguntabg28.setLayout(preguntabg28Layout);
        preguntabg28Layout.setHorizontalGroup(
            preguntabg28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg28Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt28, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg28Layout.setVerticalGroup(
            preguntabg28Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg28Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(preguntatxt28, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg28, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg27.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt27.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt27.setText("<html>\n¿Cómo te describes cuando eras estudiante?<html>\n\n<html>\n--------------------------------------------------------\n1- Estudiante sobresaliente\n--------------------------------------------------------\n2-  Estudiante Promedio\n--------------------------------------------------------\n3- Vago\n<html>");

        javax.swing.GroupLayout preguntabg27Layout = new javax.swing.GroupLayout(preguntabg27);
        preguntabg27.setLayout(preguntabg27Layout);
        preguntabg27Layout.setHorizontalGroup(
            preguntabg27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg27Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt27, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg27Layout.setVerticalGroup(
            preguntabg27Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg27Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(preguntatxt27, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg27, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg26.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt26.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt26.setText("<html>\n¿Cuál de las opciones te describen mejor?<html>\n\n<html>\n--------------------------------------------------------\n1- Orientado hacia el futuro con grandes planes y metas claras\n--------------------------------------------------------\n2- Informado por el pasado, esperanzado por el futuro y aspirando a vivir el momento\n--------------------------------------------------------\n3- Orientado al presente. Se trata de lo que se siente bien ahora\n<html>");

        javax.swing.GroupLayout preguntabg26Layout = new javax.swing.GroupLayout(preguntabg26);
        preguntabg26.setLayout(preguntabg26Layout);
        preguntabg26Layout.setHorizontalGroup(
            preguntabg26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg26Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt26, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg26Layout.setVerticalGroup(
            preguntabg26Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg26Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(preguntatxt26, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg26, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg25.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt25.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt25.setText("<html>\n¿Cuál es tu nivel de tolerancia con respecto al riesgo?<html>\n\n<html>\n--------------------------------------------------------\n1- Bajo\n--------------------------------------------------------\n2- Medio\n--------------------------------------------------------\n3- Alto\n<html>");

        javax.swing.GroupLayout preguntabg25Layout = new javax.swing.GroupLayout(preguntabg25);
        preguntabg25.setLayout(preguntabg25Layout);
        preguntabg25Layout.setHorizontalGroup(
            preguntabg25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg25Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt25, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg25Layout.setVerticalGroup(
            preguntabg25Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg25Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(preguntatxt25, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg25, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg24.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt24.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt24.setText("<html>\n¿Cuál de estos argumentos resuena mejor contigo?<html>\n\n<html>\n--------------------------------------------------------\n1- “Yo trabajo mucho, como bien y evito todo lo malo”\n--------------------------------------------------------\n2- “Trato de hacer lo correcto respecto a mi salud, a veces tengo éxito”\n--------------------------------------------------------\n3-  “Odio hacer ejercicio, y amo la comida chatarra, y eso no lo voy a cambiar”\n<html>");

        javax.swing.GroupLayout preguntabg24Layout = new javax.swing.GroupLayout(preguntabg24);
        preguntabg24.setLayout(preguntabg24Layout);
        preguntabg24Layout.setHorizontalGroup(
            preguntabg24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg24Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt24, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg24Layout.setVerticalGroup(
            preguntabg24Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg24Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(preguntatxt24, javax.swing.GroupLayout.PREFERRED_SIZE, 269, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg24, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg23.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt23.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt23.setText("<html>\nSi tuvieras que hacer 2 horas de trabajo físico arduo, como cargar muebles o cortar el pasto, ¿cuándo preferirías hacerlo para máximo desempeño y seguridad?<html>\n\n<html>\n--------------------------------------------------------\n1-  8:00 am - 10:00 am\n--------------------------------------------------------\n2-  11:00 am - 1:00 pm\n--------------------------------------------------------\n3-  6:00 pm - 8:00 pm\n<html>");

        javax.swing.GroupLayout preguntabg23Layout = new javax.swing.GroupLayout(preguntabg23);
        preguntabg23.setLayout(preguntabg23Layout);
        preguntabg23Layout.setHorizontalGroup(
            preguntabg23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg23Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt23, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg23Layout.setVerticalGroup(
            preguntabg23Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg23Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(preguntatxt23, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg23, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg22.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt22.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt22.setText("<html>¿Acostumbras a hacer siesta?<html>\n\n<html>\n--------------------------------------------------------\n1- Nunca\n--------------------------------------------------------\n2- Algunas veces en los fines de semana\n--------------------------------------------------------\n3- Si tomas una siesta, no te duermes por la noche\n\n<html>");

        javax.swing.GroupLayout preguntabg22Layout = new javax.swing.GroupLayout(preguntabg22);
        preguntabg22.setLayout(preguntabg22Layout);
        preguntabg22Layout.setHorizontalGroup(
            preguntabg22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg22Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt22, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg22Layout.setVerticalGroup(
            preguntabg22Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg22Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(preguntatxt22, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg22, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg21.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt21.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt21.setText("<html>Te consideras….<html>\n\n<html>\n--------------------------------------------------------\n1- Pensador estratégico y analítico de cerebro izquierdo\n--------------------------------------------------------\n2- Pensador equilibrado\n--------------------------------------------------------\n3- Cerebro derecho, también conocido como un pensador creativo y perspicaz.\n\n<html>");

        javax.swing.GroupLayout preguntabg21Layout = new javax.swing.GroupLayout(preguntabg21);
        preguntabg21.setLayout(preguntabg21Layout);
        preguntabg21Layout.setHorizontalGroup(
            preguntabg21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg21Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt21, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg21Layout.setVerticalGroup(
            preguntabg21Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg21Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(preguntatxt21, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg21, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg20.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt20.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt20.setText("<html>Si pudieras elegir tu bloque de 8 horas de trabajo diario, ¿qué bloque de horas consecutivas elegirías?<html>\n\n<html>\n--------------------------------------------------------\n1- 4:00 am - 12:00 am\n--------------------------------------------------------\n2- 9:00 am - 5:00 pm\n--------------------------------------------------------\n3- 1:00 pm - 9:00 pm\n\n<html>");

        javax.swing.GroupLayout preguntabg20Layout = new javax.swing.GroupLayout(preguntabg20);
        preguntabg20.setLayout(preguntabg20Layout);
        preguntabg20Layout.setHorizontalGroup(
            preguntabg20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg20Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt20, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg20Layout.setVerticalGroup(
            preguntabg20Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg20Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(preguntatxt20, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg20, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg19.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt19.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt19.setText("<html>¿ A qué hora te sientes más alerta?\n<html>\n\n<html>\n--------------------------------------------------------\n1- 1-2 horas después de despertar\n--------------------------------------------------------\n2- 2-4 horas después de despertar\n--------------------------------------------------------\n3- 4-6 horas después de despertar\n\n<html>");

        javax.swing.GroupLayout preguntabg19Layout = new javax.swing.GroupLayout(preguntabg19);
        preguntabg19.setLayout(preguntabg19Layout);
        preguntabg19Layout.setHorizontalGroup(
            preguntabg19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg19Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt19, javax.swing.GroupLayout.PREFERRED_SIZE, 409, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(198, 198, 198))
        );
        preguntabg19Layout.setVerticalGroup(
            preguntabg19Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg19Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(preguntatxt19, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg19, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg18.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt18.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt18.setText("<html>Si pudieras elegir cualquier momento del día para hacer entrenamiento físico intenso, ¿qué horario elegirías?\n<html>\n\n<html>\n--------------------------------------------------------\n1-Antes de las 8:00 am\n--------------------------------------------------------\n2-Entre 8:00 am y 4:00 pm\n--------------------------------------------------------\n3-Después de las 4:00 pm\n\n<html>");

        javax.swing.GroupLayout preguntabg18Layout = new javax.swing.GroupLayout(preguntabg18);
        preguntabg18.setLayout(preguntabg18Layout);
        preguntabg18Layout.setHorizontalGroup(
            preguntabg18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg18Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt18, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(177, 177, 177))
        );
        preguntabg18Layout.setVerticalGroup(
            preguntabg18Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg18Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(preguntatxt18, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg18, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg17.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt17.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt17.setText("<html>Si regresaras al colegio, y tuvieras que presentar un examen para entrar a la universidad, ¿qué horario preferirías para tomar el examen, un horario donde sabes que tienes máximo enfoque y concentración?\n<html>\n\n<html>\n--------------------------------------------------------\n1-Temprano en la mañana\n--------------------------------------------------------\n2-Media mañana - Media tarde\n--------------------------------------------------------\n3-En la tarde\n\n\n<html>");

        javax.swing.GroupLayout preguntabg17Layout = new javax.swing.GroupLayout(preguntabg17);
        preguntabg17.setLayout(preguntabg17Layout);
        preguntabg17Layout.setHorizontalGroup(
            preguntabg17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg17Layout.createSequentialGroup()
                .addContainerGap(193, Short.MAX_VALUE)
                .addComponent(preguntatxt17, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(177, 177, 177))
        );
        preguntabg17Layout.setVerticalGroup(
            preguntabg17Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg17Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(preguntatxt17, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg17, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg16.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt16.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt16.setText("<html>¿Cuál de las tres comidas principales del día es tu favorita?\n<html>\n\n<html>\n--------------------------------------------------------\n1-Desayuno\n--------------------------------------------------------\n2-Almuerzo\n--------------------------------------------------------\n3- Cena\n\n\n<html>");

        javax.swing.GroupLayout preguntabg16Layout = new javax.swing.GroupLayout(preguntabg16);
        preguntabg16.setLayout(preguntabg16Layout);
        preguntabg16Layout.setHorizontalGroup(
            preguntabg16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg16Layout.createSequentialGroup()
                .addContainerGap(208, Short.MAX_VALUE)
                .addComponent(preguntatxt16, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(189, 189, 189))
        );
        preguntabg16Layout.setVerticalGroup(
            preguntabg16Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg16Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(preguntatxt16, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg16, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg15.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt15.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt15.setText("<html>Cómo es tu experiencia con el jetlag (descompensación horaria) después de un viaje largo en avión\n<html>\n\n<html>\n--------------------------------------------------------\n1-Te da muy duro, siempre\n--------------------------------------------------------\n2-Te ajustas a las 48 horas \n--------------------------------------------------------\n3- Te ajustas rápidamente\n\n\n<html>");

        javax.swing.GroupLayout preguntabg15Layout = new javax.swing.GroupLayout(preguntabg15);
        preguntabg15.setLayout(preguntabg15Layout);
        preguntabg15Layout.setHorizontalGroup(
            preguntabg15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg15Layout.createSequentialGroup()
                .addContainerGap(208, Short.MAX_VALUE)
                .addComponent(preguntatxt15, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(189, 189, 189))
        );
        preguntabg15Layout.setVerticalGroup(
            preguntabg15Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg15Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(preguntatxt15, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg15, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg14.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt14.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt14.setText("<html>¿A qué hora te levantas los fines de semana?\n<html>\n\n<html>\n--------------------------------------------------------\n1-Misma hora que entre semana\n--------------------------------------------------------\n2-Entre 45 y 90 minutos después de la hora entre semana\n--------------------------------------------------------\n3- + de 90 minutos después de la hora habitual en semana\n\n\n<html>");

        javax.swing.GroupLayout preguntabg14Layout = new javax.swing.GroupLayout(preguntabg14);
        preguntabg14.setLayout(preguntabg14Layout);
        preguntabg14Layout.setHorizontalGroup(
            preguntabg14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg14Layout.createSequentialGroup()
                .addContainerGap(208, Short.MAX_VALUE)
                .addComponent(preguntatxt14, javax.swing.GroupLayout.PREFERRED_SIZE, 403, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(189, 189, 189))
        );
        preguntabg14Layout.setVerticalGroup(
            preguntabg14Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg14Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addComponent(preguntatxt14, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(25, Short.MAX_VALUE))
        );

        testbg.add(preguntabg14, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg13.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt13.setFont(new java.awt.Font("Segoe UI", 0, 18)); // NOI18N
        preguntatxt13.setText("<html>Los días en los que debes despertar a una hora determinada, ¿usas reloj despertador?\n<html>\n\n<html>\n--------------------------------------------------------\n1-No hay necesidad. Me despierto a tiempo\n--------------------------------------------------------\n2-Si, alarma + posponer 2 veces\n--------------------------------------------------------\n3-Si, alarma + posponer varias veces + alarma extra\n\n\n<html>");

        javax.swing.GroupLayout preguntabg13Layout = new javax.swing.GroupLayout(preguntabg13);
        preguntabg13.setLayout(preguntabg13Layout);
        preguntabg13Layout.setHorizontalGroup(
            preguntabg13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg13Layout.createSequentialGroup()
                .addGap(181, 181, 181)
                .addComponent(preguntatxt13, javax.swing.GroupLayout.PREFERRED_SIZE, 430, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(189, Short.MAX_VALUE))
        );
        preguntabg13Layout.setVerticalGroup(
            preguntabg13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg13Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addComponent(preguntatxt13, javax.swing.GroupLayout.PREFERRED_SIZE, 259, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(16, Short.MAX_VALUE))
        );

        testbg.add(preguntabg13, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg12.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt12.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt12.setText("<html>Si no tuvieras nada que hacer mañana, y te dieras el permiso de dormir hasta la hora que quieras, ¿alrededor de qué hora te despertarías?.<html>\n\n<html>\n1-Antes de 6:30 am\n2-Entre 6:30 y 8:45 am\n3-Después de 8:45 am\n\n<html>");

        javax.swing.GroupLayout preguntabg12Layout = new javax.swing.GroupLayout(preguntabg12);
        preguntabg12.setLayout(preguntabg12Layout);
        preguntabg12Layout.setHorizontalGroup(
            preguntabg12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg12Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(preguntatxt12, javax.swing.GroupLayout.DEFAULT_SIZE, 771, Short.MAX_VALUE)
                .addContainerGap())
        );
        preguntabg12Layout.setVerticalGroup(
            preguntabg12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg12Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt12, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg12, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg11.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt11.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt11.setText("<html>Soy perfeccionista.<html>");

        javax.swing.GroupLayout preguntabg11Layout = new javax.swing.GroupLayout(preguntabg11);
        preguntabg11.setLayout(preguntabg11Layout);
        preguntabg11Layout.setHorizontalGroup(
            preguntabg11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg11Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt11, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg11Layout.setVerticalGroup(
            preguntabg11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg11Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt11, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg11, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg10.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt10.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt10.setText("<html>Se me va el sueño con pensamientos rumiantes sobre hechos del pasado y sobre lo que puede suceder en el futuro.<html>");

        javax.swing.GroupLayout preguntabg10Layout = new javax.swing.GroupLayout(preguntabg10);
        preguntabg10.setLayout(preguntabg10Layout);
        preguntabg10Layout.setHorizontalGroup(
            preguntabg10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg10Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt10, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg10Layout.setVerticalGroup(
            preguntabg10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg10Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt10, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg10, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg9.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt9.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt9.setText("<html>Cuando estaba en el colegio / universidad, me sentía constantemente ansioso(a) por mis calificaciones.<html>");

        javax.swing.GroupLayout preguntabg9Layout = new javax.swing.GroupLayout(preguntabg9);
        preguntabg9.setLayout(preguntabg9Layout);
        preguntabg9Layout.setHorizontalGroup(
            preguntabg9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg9Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt9, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg9Layout.setVerticalGroup(
            preguntabg9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg9Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt9, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg9, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg8.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt8.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt8.setText("<html>Tengo patrones de sueño que varían mucho. A veces me despierto a media noche con grandes ideas, soluciones a problemas, etc.<html>");

        javax.swing.GroupLayout preguntabg8Layout = new javax.swing.GroupLayout(preguntabg8);
        preguntabg8.setLayout(preguntabg8Layout);
        preguntabg8Layout.setHorizontalGroup(
            preguntabg8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg8Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt8, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg8Layout.setVerticalGroup(
            preguntabg8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg8Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt8, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg8, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg7.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt7.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt7.setText("<html>He sido diagnosticado(a) por un doctor, o me he auto-diagnosticado como insomne.<html>");

        javax.swing.GroupLayout preguntabg7Layout = new javax.swing.GroupLayout(preguntabg7);
        preguntabg7.setLayout(preguntabg7Layout);
        preguntabg7Layout.setHorizontalGroup(
            preguntabg7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg7Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt7, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg7Layout.setVerticalGroup(
            preguntabg7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg7Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt7, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg7, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg6.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt6.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt6.setText("<html>Es frecuente que me preocupe por mínimos detalles.<html>");

        javax.swing.GroupLayout preguntabg6Layout = new javax.swing.GroupLayout(preguntabg6);
        preguntabg6.setLayout(preguntabg6Layout);
        preguntabg6Layout.setHorizontalGroup(
            preguntabg6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg6Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt6, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg6Layout.setVerticalGroup(
            preguntabg6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg6Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt6, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg6, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg5.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt5.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt5.setText("<html>Frecuentemente estoy irritable debido a que me siento fatigado.<html>");

        javax.swing.GroupLayout preguntabg5Layout = new javax.swing.GroupLayout(preguntabg5);
        preguntabg5.setLayout(preguntabg5Layout);
        preguntabg5Layout.setHorizontalGroup(
            preguntabg5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg5Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt5, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg5Layout.setVerticalGroup(
            preguntabg5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg5Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt5, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg5, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg4.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt4.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt4.setText("<html>No puedo dormir bien en los aviones, ni siquiera cuando tengo antifaz y/o tapones para los oídos.<html>");

        javax.swing.GroupLayout preguntabg4Layout = new javax.swing.GroupLayout(preguntabg4);
        preguntabg4.setLayout(preguntabg4Layout);
        preguntabg4Layout.setHorizontalGroup(
            preguntabg4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg4Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt4, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg4Layout.setVerticalGroup(
            preguntabg4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg4Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt4, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg4, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg3.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt3.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt3.setText("<html>Normalmente me despierto antes de que mi alarma del despertador suene.<html>");

        javax.swing.GroupLayout preguntabg3Layout = new javax.swing.GroupLayout(preguntabg3);
        preguntabg3.setLayout(preguntabg3Layout);
        preguntabg3Layout.setHorizontalGroup(
            preguntabg3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg3Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt3, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg3Layout.setVerticalGroup(
            preguntabg3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg3Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt3, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg3, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg2.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt2.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt2.setText("<html>No me apasiona pensar en qué comer, ni la comida en general.<html>");

        javax.swing.GroupLayout preguntabg2Layout = new javax.swing.GroupLayout(preguntabg2);
        preguntabg2.setLayout(preguntabg2Layout);
        preguntabg2Layout.setHorizontalGroup(
            preguntabg2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg2Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt2, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg2Layout.setVerticalGroup(
            preguntabg2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg2Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt2, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg2, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        preguntabg1.setBackground(new java.awt.Color(255, 255, 255));

        preguntatxt1.setFont(new java.awt.Font("Segoe UI", 0, 24)); // NOI18N
        preguntatxt1.setText("<html>Cualquier ruido o luz, me despierta fácilmente o me despierta o hace que permanezca en vigilia.<html>");

        javax.swing.GroupLayout preguntabg1Layout = new javax.swing.GroupLayout(preguntabg1);
        preguntabg1.setLayout(preguntabg1Layout);
        preguntabg1Layout.setHorizontalGroup(
            preguntabg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, preguntabg1Layout.createSequentialGroup()
                .addContainerGap(124, Short.MAX_VALUE)
                .addComponent(preguntatxt1, javax.swing.GroupLayout.PREFERRED_SIZE, 560, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(116, 116, 116))
        );
        preguntabg1Layout.setVerticalGroup(
            preguntabg1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(preguntabg1Layout.createSequentialGroup()
                .addGap(43, 43, 43)
                .addComponent(preguntatxt1, javax.swing.GroupLayout.PREFERRED_SIZE, 213, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        testbg.add(preguntabg1, new org.netbeans.lib.awtextra.AbsoluteConstraints(0, 90, 800, 300));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(testbg, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(testbg, javax.swing.GroupLayout.DEFAULT_SIZE, 500, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void exittxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exittxtMouseClicked
        System.exit(0);
    }//GEN-LAST:event_exittxtMouseClicked

    private void exittxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exittxtMouseEntered
       extbtn.setBackground(Color.red);
       exittxt.setForeground(Color.white);
    }//GEN-LAST:event_exittxtMouseEntered

    private void exittxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_exittxtMouseExited
       extbtn.setBackground(new Color(55,67,136));
        exittxt.setForeground(Color.black);
    }//GEN-LAST:event_exittxtMouseExited

    private void HEADERMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HEADERMousePressed
        xMouse = evt.getX();
        yMouse = evt.getY();
    }//GEN-LAST:event_HEADERMousePressed

    private void HEADERMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_HEADERMouseDragged
       int x = evt.getXOnScreen();
       int y = evt.getYOnScreen();
       this.setLocation(x - xMouse, y - yMouse);
    }//GEN-LAST:event_HEADERMouseDragged

    private void vbtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vbtnMouseEntered
     vbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_vbtnMouseEntered

    private void vbtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_vbtnMouseExited
        vbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_vbtnMouseExited

    private void FbtnMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FbtnMouseEntered
        Fbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_FbtnMouseEntered

    private void FbtnMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FbtnMouseExited
        Fbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_FbtnMouseExited

    private void VtxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VtxtMouseClicked
        if (contverd>=7){
            
        Cronotipo cronotipo = new Cronotipo();
    cronotipo.setVisible(true);
    dispose();

        }else{
        contverd++;
        cambiarPregunta();}
        
    }//GEN-LAST:event_VtxtMouseClicked

    private void FtxtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FtxtMouseClicked
         if (contverd>=7){
            
        Cronotipo cronotipo = new Cronotipo();
    cronotipo.setVisible(true);
    dispose();
        }else{
        cambiarPregunta();}
    }//GEN-LAST:event_FtxtMouseClicked

    private void VtxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VtxtMouseEntered
        vbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_VtxtMouseEntered

    private void VtxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_VtxtMouseExited
        vbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_VtxtMouseExited

    private void FtxtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FtxtMouseEntered
        Fbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_FtxtMouseEntered

    private void FtxtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_FtxtMouseExited
        Fbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_FtxtMouseExited

    private void opcion2txtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion2txtMouseClicked
         if(pregunta==31){
           puntuacion=puntuacion+2;
           System.out.print(puntuacion);
         Cronotipo cronotipo = new Cronotipo();
    cronotipo.setVisible(true);
    dispose();
        }else{
        puntuacion=puntuacion+2;
        cambiarPregunta();
        }
    }//GEN-LAST:event_opcion2txtMouseClicked

    private void opcion2txtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion2txtMouseEntered
        vbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_opcion2txtMouseEntered

    private void opcion2txtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion2txtMouseExited
        Fbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_opcion2txtMouseExited

    private void opcion2MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion2MouseEntered
        vbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_opcion2MouseEntered

    private void opcion2MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion2MouseExited
        Fbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_opcion2MouseExited

    private void opcion1txtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion1txtMouseClicked
        if(pregunta==31){
            puntuacion++;
            System.out.print(puntuacion);
         Cronotipo cronotipo = new Cronotipo();
    cronotipo.setVisible(true);
    dispose();
        }else{
        puntuacion++;
        cambiarPregunta();
        }
    }//GEN-LAST:event_opcion1txtMouseClicked

    private void opcion1txtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion1txtMouseEntered
       vbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_opcion1txtMouseEntered

    private void opcion1txtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion1txtMouseExited
        Fbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_opcion1txtMouseExited

    private void opcion1MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion1MouseEntered
        vbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_opcion1MouseEntered

    private void opcion1MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion1MouseExited
        Fbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_opcion1MouseExited

    private void opcion3txtMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion3txtMouseClicked
        if(pregunta==31){
            puntuacion=puntuacion+3;
            System.out.print(puntuacion);
         Cronotipo cronotipo = new Cronotipo();
    cronotipo.setVisible(true);
    dispose();
        }else{
        puntuacion=puntuacion+3;
        cambiarPregunta();
        }
    }//GEN-LAST:event_opcion3txtMouseClicked

    private void opcion3txtMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion3txtMouseEntered
        vbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_opcion3txtMouseEntered

    private void opcion3txtMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion3txtMouseExited
        Fbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_opcion3txtMouseExited

    private void opcion3MouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion3MouseEntered
        vbtn.setBackground(new Color(98, 112, 191));
    }//GEN-LAST:event_opcion3MouseEntered

    private void opcion3MouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_opcion3MouseExited
       Fbtn.setBackground(new Color(55, 67, 136));
    }//GEN-LAST:event_opcion3MouseExited

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(testcrono.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(testcrono.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(testcrono.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(testcrono.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(() -> {
            new testcrono().setVisible(true);
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JPanel Fbtn;
    private javax.swing.JLabel Ftxt;
    private javax.swing.JPanel HEADER;
    private javax.swing.JLabel Vtxt;
    private javax.swing.JLabel exittxt;
    private javax.swing.JPanel extbtn;
    private javax.swing.JPanel opcion1;
    private javax.swing.JLabel opcion1txt;
    private javax.swing.JPanel opcion2;
    private javax.swing.JLabel opcion2txt;
    private javax.swing.JPanel opcion3;
    private javax.swing.JLabel opcion3txt;
    private javax.swing.JPanel preguntabg;
    private javax.swing.JPanel preguntabg1;
    private javax.swing.JPanel preguntabg10;
    private javax.swing.JPanel preguntabg11;
    private javax.swing.JPanel preguntabg12;
    private javax.swing.JPanel preguntabg13;
    private javax.swing.JPanel preguntabg14;
    private javax.swing.JPanel preguntabg15;
    private javax.swing.JPanel preguntabg16;
    private javax.swing.JPanel preguntabg17;
    private javax.swing.JPanel preguntabg18;
    private javax.swing.JPanel preguntabg19;
    private javax.swing.JPanel preguntabg2;
    private javax.swing.JPanel preguntabg20;
    private javax.swing.JPanel preguntabg21;
    private javax.swing.JPanel preguntabg22;
    private javax.swing.JPanel preguntabg23;
    private javax.swing.JPanel preguntabg24;
    private javax.swing.JPanel preguntabg25;
    private javax.swing.JPanel preguntabg26;
    private javax.swing.JPanel preguntabg27;
    private javax.swing.JPanel preguntabg28;
    private javax.swing.JPanel preguntabg29;
    private javax.swing.JPanel preguntabg3;
    private javax.swing.JPanel preguntabg30;
    private javax.swing.JPanel preguntabg31;
    private javax.swing.JPanel preguntabg4;
    private javax.swing.JPanel preguntabg5;
    private javax.swing.JPanel preguntabg6;
    private javax.swing.JPanel preguntabg7;
    private javax.swing.JPanel preguntabg8;
    private javax.swing.JPanel preguntabg9;
    private javax.swing.JLabel preguntatxt;
    private javax.swing.JLabel preguntatxt1;
    private javax.swing.JLabel preguntatxt10;
    private javax.swing.JLabel preguntatxt11;
    private javax.swing.JLabel preguntatxt12;
    private javax.swing.JLabel preguntatxt13;
    private javax.swing.JLabel preguntatxt14;
    private javax.swing.JLabel preguntatxt15;
    private javax.swing.JLabel preguntatxt16;
    private javax.swing.JLabel preguntatxt17;
    private javax.swing.JLabel preguntatxt18;
    private javax.swing.JLabel preguntatxt19;
    private javax.swing.JLabel preguntatxt2;
    private javax.swing.JLabel preguntatxt20;
    private javax.swing.JLabel preguntatxt21;
    private javax.swing.JLabel preguntatxt22;
    private javax.swing.JLabel preguntatxt23;
    private javax.swing.JLabel preguntatxt24;
    private javax.swing.JLabel preguntatxt25;
    private javax.swing.JLabel preguntatxt26;
    private javax.swing.JLabel preguntatxt27;
    private javax.swing.JLabel preguntatxt28;
    private javax.swing.JLabel preguntatxt29;
    private javax.swing.JLabel preguntatxt3;
    private javax.swing.JLabel preguntatxt30;
    private javax.swing.JLabel preguntatxt31;
    private javax.swing.JLabel preguntatxt4;
    private javax.swing.JLabel preguntatxt5;
    private javax.swing.JLabel preguntatxt6;
    private javax.swing.JLabel preguntatxt7;
    private javax.swing.JLabel preguntatxt8;
    private javax.swing.JLabel preguntatxt9;
    private javax.swing.JPanel testbg;
    private javax.swing.JPanel vbtn;
    // End of variables declaration//GEN-END:variables
}
